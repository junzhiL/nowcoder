package com.nowcoder.model;

/**
 * Created by nowcoder on 2016/7/9.
 */
public class EntityType {
    public static int ENTITY_NEWS = 1;
    public static int ENTITY_COMMENT = 2;
}
