package com.nowcoder;

/**
 * Created by nowcoder on 2016/6/25.
 */
public interface Talking {
    void say();
}
